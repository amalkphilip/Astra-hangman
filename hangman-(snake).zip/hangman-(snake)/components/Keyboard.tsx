
import React from 'react';
import { ALPHABET } from '../constants';

interface KeyboardProps {
  onGuess: (letter: string) => void;
  guessedLetters: string[];
  wordToGuess: string;
  gameStatus: 'playing' | 'won' | 'lost';
}

const Keyboard: React.FC<KeyboardProps> = ({ onGuess, guessedLetters, wordToGuess, gameStatus }) => {
  return (
    <div className="grid grid-cols-7 sm:grid-cols-9 gap-2 w-full max-w-xl mt-4">
      {ALPHABET.map((letter) => {
        const isGuessed = guessedLetters.includes(letter);
        const isCorrect = isGuessed && wordToGuess.includes(letter);
        const isWrong = isGuessed && !wordToGuess.includes(letter);
        const isDisabled = isGuessed || gameStatus !== 'playing';

        return (
          <button
            key={letter}
            onClick={() => onGuess(letter)}
            disabled={isDisabled}
            className={`
              font-bold text-lg md:text-xl p-2 rounded-md aspect-square
              flex items-center justify-center
              transition-all duration-200
              ${isCorrect ? 'bg-green-600 text-white' : ''}
              ${isWrong ? 'bg-red-700 text-white' : ''}
              ${!isGuessed ? 'bg-slate-700 hover:bg-slate-600' : ''}
              ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}
            `}
          >
            {letter}
          </button>
        );
      })}
    </div>
  );
};

export default Keyboard;
