import React from 'react';

interface HeaderProps {
  clue: string;
}

const Header: React.FC<HeaderProps> = ({ clue }) => {
  return (
    <header className="text-center">
      <h1 className="text-4xl md:text-5xl font-bold text-cyan-400 tracking-wider">
        Hangman
      </h1>
      <p className="text-slate-400 mt-2">Tech Edition: Guess the technical term!</p>
      <p className="text-cyan-300 mt-4 text-lg md:text-xl font-semibold bg-slate-800 p-3 rounded-md max-w-2xl mx-auto">
        Clue: {clue}
      </p>
    </header>
  );
};

export default Header;
