
import React from 'react';

interface NotificationProps {
  show: boolean;
}

const Notification: React.FC<NotificationProps> = ({ show }) => {
  return (
    <div
      className={`
        fixed bottom-10 bg-slate-700 text-white p-4 rounded-lg shadow-lg
        transition-transform duration-300 ease-out
        ${show ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}
      `}
      style={{ pointerEvents: show ? 'auto' : 'none' }}
    >
      <p>You have already entered this letter!</p>
    </div>
  );
};

export default Notification;
