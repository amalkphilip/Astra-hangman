
import React from 'react';

interface WordProps {
  wordToGuess: string;
  guessedLetters: string[];
  gameStatus: 'playing' | 'won' | 'lost';
}

const Word: React.FC<WordProps> = ({ wordToGuess, guessedLetters, gameStatus }) => {
  const isRevealed = gameStatus === 'lost';

  return (
    <div className="flex gap-2 md:gap-4 my-8 justify-center">
      {wordToGuess.split('').map((letter, index) => (
        <span
          key={index}
          className={`
            w-10 h-14 md:w-12 md:h-16
            border-b-4
            flex items-center justify-center
            text-3xl md:text-4xl font-bold uppercase
            transition-all duration-300
            ${
              isRevealed && !guessedLetters.includes(letter)
                ? 'border-red-500 text-red-500'
                : 'border-slate-500 text-slate-100'
            }
          `}
        >
          {guessedLetters.includes(letter) || isRevealed ? letter : ''}
        </span>
      ))}
    </div>
  );
};

export default Word;
