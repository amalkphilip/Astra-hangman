
import React from 'react';

interface PopupProps {
  gameStatus: 'playing' | 'won' | 'lost';
  wordToGuess: string;
  playAgain: () => void;
}

const Popup: React.FC<PopupProps> = ({ gameStatus, wordToGuess, playAgain }) => {
  if (gameStatus === 'playing') {
    return null;
  }

  const isWin = gameStatus === 'won';
  const finalMessage = isWin ? 'Congratulations! You won! 🥳' : 'Unfortunately, you lost. 😕';
  const revealMessage = `...the word was: ${wordToGuess}`;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-10">
      <div className="bg-slate-800 p-8 rounded-lg shadow-2xl text-center max-w-sm mx-auto">
        <h2 className={`text-3xl font-bold mb-4 ${isWin ? 'text-green-400' : 'text-red-400'}`}>
          {finalMessage}
        </h2>
        {!isWin && <h3 className="text-xl text-slate-300 mb-6">{revealMessage}</h3>}
        <button
          onClick={playAgain}
          className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-300 text-lg"
        >
          Play Again
        </button>
      </div>
    </div>
  );
};

export default Popup;
