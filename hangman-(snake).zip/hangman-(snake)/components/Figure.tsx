
import React from 'react';

interface FigureProps {
  mistakes: number;
}

const Figure: React.FC<FigureProps> = ({ mistakes }) => {
  const parts = [
    // Head
    <circle key="head" cx="200" cy="90" r="30" strokeWidth="8" />,
    // Body
    <line key="body" x1="200" y1="120" x2="200" y2="220" strokeWidth="8" />,
    // Left Arm
    <line key="left-arm" x1="200" y1="150" x2="140" y2="190" strokeWidth="8" />,
    // Right Arm
    <line key="right-arm" x1="200" y1="150" x2="260" y2="190" strokeWidth="8" />,
    // Left Leg
    <line key="left-leg" x1="200" y1="220" x2="150" y2="280" strokeWidth="8" />,
    // Right Leg
    <line key="right-leg" x1="200" y1="220" x2="250" y2="280" strokeWidth="8" />,
  ];

  return (
    <div className="relative w-64 h-80 md:w-80 md:h-96">
      <svg viewBox="0 0 300 350" className="w-full h-full">
        {/* Gallows */}
        <line x1="20" y1="330" x2="150" y2="330" stroke="white" strokeWidth="8" />
        <line x1="85" y1="330" x2="85" y2="20" stroke="white" strokeWidth="8" />
        <line x1="85" y1="20" x2="200" y2="20" stroke="white" strokeWidth="8" />
        <line x1="200" y1="20" x2="200" y2="60" stroke="white" strokeWidth="8" />
        
        {/* Figure Parts */}
        <g fill="none" stroke="#e53e3e" strokeLinecap="round">
            {parts.slice(0, mistakes)}
        </g>
      </svg>
    </div>
  );
};

export default Figure;
