import React, { useState, useEffect, useCallback } from 'react';
import { WORDS, WordData } from './constants';
import Header from './components/Header';
import Figure from './components/Figure';
import Word from './components/Word';
import Keyboard from './components/Keyboard';
import Popup from './components/Popup';
import Notification from './components/Notification';

type GameStatus = 'playing' | 'won' | 'lost';

const selectWord = (): WordData => WORDS[Math.floor(Math.random() * WORDS.length)];

function App() {
  const [selectedWord, setSelectedWord] = useState<WordData>(selectWord());
  const [guessedLetters, setGuessedLetters] = useState<string[]>([]);
  const [gameStatus, setGameStatus] = useState<GameStatus>('playing');
  const [showNotification, setShowNotification] = useState<boolean>(false);

  const wordToGuess = selectedWord.word;
  const wrongLetters = guessedLetters.filter(letter => !wordToGuess.includes(letter));
  const correctLetters = guessedLetters.filter(letter => wordToGuess.includes(letter));
  const mistakes = wrongLetters.length;
  const maxMistakes = 6;

  const handleGuess = useCallback((letter: string) => {
    if (gameStatus !== 'playing' || guessedLetters.includes(letter)) {
      if (guessedLetters.includes(letter)) {
        setShowNotification(true);
        setTimeout(() => setShowNotification(false), 2000);
      }
      return;
    }
    setGuessedLetters(currentLetters => [...currentLetters, letter]);
  }, [guessedLetters, gameStatus]);
  
  const playAgain = () => {
    setGuessedLetters([]);
    setSelectedWord(selectWord());
    setGameStatus('playing');
  };

  useEffect(() => {
    const isWin = wordToGuess.split('').every(letter => correctLetters.includes(letter));
    if (isWin && gameStatus === 'playing') {
      setGameStatus('won');
    } else if (mistakes >= maxMistakes && gameStatus === 'playing') {
      setGameStatus('lost');
    }
  }, [correctLetters, mistakes, wordToGuess, gameStatus]);
  
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const { key, keyCode } = event;
      if (keyCode >= 65 && keyCode <= 90) { // A-Z
        handleGuess(key.toUpperCase());
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleGuess]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-slate-900 text-slate-100">
      <Header clue={selectedWord.clue} />
      <div className="w-full max-w-4xl mx-auto flex flex-col lg:flex-row items-center justify-around gap-8 mt-4">
        <Figure mistakes={mistakes} />
        <div className="flex flex-col items-center w-full lg:w-1/2">
          <Word wordToGuess={wordToGuess} guessedLetters={correctLetters} gameStatus={gameStatus} />
          <Keyboard
            onGuess={handleGuess}
            guessedLetters={guessedLetters}
            wordToGuess={wordToGuess}
            gameStatus={gameStatus}
          />
        </div>
      </div>
      <Popup
        gameStatus={gameStatus}
        wordToGuess={wordToGuess}
        playAgain={playAgain}
      />
      <Notification show={showNotification} />
    </div>
  );
}

export default App;
